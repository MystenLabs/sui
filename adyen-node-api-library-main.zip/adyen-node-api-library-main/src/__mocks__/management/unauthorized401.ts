export const unauthorizedError = {
    "type": "https://docs.adyen.com/errors/unauthorized",
    "title": "Unauthorized",
    "status": 401,
    "errorCode": "00_401"
};
