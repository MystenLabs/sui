import { version } from "../../package.json";

class LibraryConstants {
    public static LIB_NAME = "adyen-node-api-library";
    public static LIB_VERSION: string = version;
}

export default LibraryConstants;