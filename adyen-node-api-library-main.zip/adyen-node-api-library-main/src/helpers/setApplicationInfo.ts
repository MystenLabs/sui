/*
 *                       ######
 *                       ######
 * ############    ####( ######  #####. ######  ############   ############
 * #############  #####( ######  #####. ######  #############  #############
 *        ######  #####( ######  #####. ######  #####  ######  #####  ######
 * ###### ######  #####( ######  #####. ######  #####  #####   #####  ######
 * ###### ######  #####( ######  #####. ######  #####          #####  ######
 * #############  #############  #############  #############  #####  ######
 *  ############   ############  #############   ############  #####  ######
 *                                      ######
 *                               #############
 *                               ############
 * Adyen NodeJS API Library
 * Copyright (c) 2020 Adyen B.V.
 * This file is open source and available under the MIT license.
 * See the LICENSE file for more info.
 */

import { ApplicationInfo } from "../typings/applicationInfo";

interface AppInfo { applicationInfo?: ApplicationInfo }

function setApplicationInfo<T extends AppInfo>(request: T): T {
    const hasApplicationInfo = "applicationInfo" in request;
    const requestAppInfo = hasApplicationInfo && request.applicationInfo;
    const applicationInfo = new ApplicationInfo();
    return {...request, applicationInfo: {...requestAppInfo, ...applicationInfo}};
}


export default setApplicationInfo;
