#!/usr/bin/python3
import sys
from dsc_datatool import main

if __name__ == "__main__":
    sys.exit(main())
