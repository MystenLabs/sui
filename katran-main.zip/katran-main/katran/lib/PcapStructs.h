/* Copyright (C) 2018-present, Facebook, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#pragma once

namespace katran {

// reference to headers format:
// https://wiki.wireshark.org/Development/LibpcapFileFormat
struct pcap_hdr_s {
  uint32_t magic_number; /* magic number */
  uint16_t version_major; /* major version number */
  uint16_t version_minor; /* minor version number */
  int32_t thiszone; /* GMT to local correction */
  uint32_t sigfigs; /* accuracy of timestamps */
  uint32_t snaplen; /* max length of captured packets, in octets */
  uint32_t network; /* data link type */
};

struct pcaprec_hdr_s {
  uint32_t ts_sec; /* timestamp seconds */
  uint32_t ts_usec; /* timestamp microseconds */
  uint32_t incl_len; /* number of octets of packet saved in file */
  uint32_t orig_len; /* actual length of packet */
};

} // namespace katran
