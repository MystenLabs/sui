// Copyright (c) Meta Platforms, Inc. and affiliates.

#pragma once

namespace katran {

unsigned char kBalancerKernProgBuffer[] = {__HexdumpPlaceholder__};

} // namespace katran
