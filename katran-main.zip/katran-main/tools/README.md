# collection of tools for katran

### xdpdump
tcpdump like tool, which is working in XDP environment

### tcpdump_encap_helper
helper script to create filters for tcpdump based on inner ip header

### start_katran
helper tool (example of how it could looks like to be more precise)
to do cpu/NUMA topology discovery, NIC's IRQ affinitization and start katran
server (GRPc only in this example)
